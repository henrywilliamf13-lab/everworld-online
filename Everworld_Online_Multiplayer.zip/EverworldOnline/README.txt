EVERWORLD ONLINE MULTIPLAYER

FILES
- public/index.html: complete game client
- server.js: real-time multiplayer server
- package.json: server dependencies

RUN LOCALLY
1. Install Node.js 20 or newer from https://nodejs.org/
2. Open Command Prompt in this folder.
3. Run: npm install
4. Run: npm start
5. Open http://localhost:3000 in Chrome.
6. Open a second browser window and join using the same room code to test.

PUT IT ONLINE WITH RENDER
1. Upload the contents of this folder to a GitHub repository.
2. In Render, create a New Web Service and connect that repository.
3. Build command: npm install
4. Start command: npm start
5. Deploy. Render gives you a public HTTPS website address.
6. Open that address and give friends the same website address and room code.

SAFETY
Use a nickname, not your real name. Do not share your home address, school,
phone number, passwords, or private information in chat. Share the room code
only with people you trust. This prototype chat is not moderated and messages
are not saved. Rooms reset if the server restarts.
